const { allTodoCheck, deleteTodoById } = require('./todo.js');

deleteTodoById(5);

console.log(allTodoCheck());
